package com.example.corderroartzfirstapplication;

public class DataItem {
    private int id;
    private String itemName;
    private String date;

    public DataItem(int id, String itemName, String date) {
        this.id = id;
        this.itemName = itemName;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}