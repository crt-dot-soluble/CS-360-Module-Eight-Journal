package com.example.corderroartzfirstapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.DataViewHolder> {

    private final List<DataItem> dataList;
    private final OnDeleteClickListener deleteClickListener;

    public DataAdapter(List<DataItem> dataList, OnDeleteClickListener deleteClickListener) {
        this.dataList = dataList;
        this.deleteClickListener = deleteClickListener;
    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_data, parent, false);
        return new DataViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position) {
        DataItem dataItem = dataList.get(position);

        // Set row number, item name, and date
        holder.rowNumberTextView.setText(String.valueOf(position + 1)); // Row number (1-based index)
        holder.itemNameTextView.setText(dataItem.getItemName());
        holder.dateTextView.setText(dataItem.getDate());

        // Handle delete button click
        holder.deleteButton.setOnClickListener(v -> {
            if (deleteClickListener != null) {
                deleteClickListener.onDeleteClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class DataViewHolder extends RecyclerView.ViewHolder {
        TextView rowNumberTextView;
        TextView itemNameTextView;
        TextView dateTextView;
        Button deleteButton;

        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
            rowNumberTextView = itemView.findViewById(R.id.rowNumberTextView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }
}