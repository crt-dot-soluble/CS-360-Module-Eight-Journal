package com.example.corderroartzfirstapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText nameText;
    private Button buttonSayHello;
    private TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);

        // Disable buttonSayHello by default
        buttonSayHello.setEnabled(false);

        // Add a textChangedListener to nameText to dynamically enable/disable buttonSayHello
        nameText.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Enable buttonSayHello if text is entered; disable it if text is empty
                buttonSayHello.setEnabled(s.length() > 0);
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });
    }

    // Function to display a greeting
    public void SayHello(View view) {
        String name = nameText.getText().toString().trim();
        if (name.isEmpty()) {
            return;
        }

        String greeting = "Hello, " + name + "!";
        textGreeting.setText(greeting);
    }
}
