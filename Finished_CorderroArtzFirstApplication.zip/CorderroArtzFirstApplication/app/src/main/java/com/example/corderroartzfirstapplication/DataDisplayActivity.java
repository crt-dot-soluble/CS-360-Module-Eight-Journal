package com.example.corderroartzfirstapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 123;
    private RecyclerView dataRecyclerView;
    private DataAdapter dataAdapter;
    private List<DataItem> dataList;
    private Button addDataButton;
    private EditText itemNameInput;
    private DatabaseHelper dbHelper;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Get the username from the intent
        username = getIntent().getStringExtra("username");

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Initialize UI components
        dataRecyclerView = findViewById(R.id.dataRecyclerView);
        addDataButton = findViewById(R.id.addDataButton);
        itemNameInput = findViewById(R.id.itemNameInput);

        // Initialize data list and adapter
        dataList = new ArrayList<>();
        dataAdapter = new DataAdapter(dataList, position -> {
            // Remove item from list and notify adapter
            DataItem dataItem = dataList.get(position);
            dbHelper.deleteDataItem(dataItem.getId());
            dataList.remove(position);
            dataAdapter.notifyItemRemoved(position);
            Toast.makeText(DataDisplayActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
        });

        // Set up RecyclerView
        dataRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        dataRecyclerView.setAdapter(dataAdapter);

        // Load data from the database
        loadDataFromDatabase();

        // Handle Add Data button click
        addDataButton.setOnClickListener(v -> {
            String itemName = itemNameInput.getText().toString().trim();

            if (TextUtils.isEmpty(itemName)) {
                Toast.makeText(DataDisplayActivity.this, "Please enter an item name", Toast.LENGTH_SHORT).show();
            } else {
                long newRowId = dbHelper.insertDataItem(itemName, "2024-12-08");
                if (newRowId != -1) {
                    loadDataFromDatabase();
                    itemNameInput.setText("");
                    Toast.makeText(DataDisplayActivity.this, "Item added", Toast.LENGTH_SHORT).show();

                    // Retrieve the phone number from the database
                    String phoneNumber = dbHelper.getPhoneNumber(username);
                    if (!TextUtils.isEmpty(phoneNumber)) {
                        // Check for SMS permission and send notification if granted
                        if (ContextCompat.checkSelfPermission(DataDisplayActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                            sendSMSNotification(phoneNumber, "Item added: " + itemName);
                        } else {
                            requestSmsPermission();
                        }
                    }
                } else {
                    Toast.makeText(DataDisplayActivity.this, "Failed to add item", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Request SMS permission on startup
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestSmsPermission();
        }
    }

    // Load data from the database
    private void loadDataFromDatabase() {
        dataList.clear();
        Cursor cursor = dbHelper.getAllDataItems();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATA_ID));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE));

                DataItem dataItem = new DataItem(id, itemName, date);
                dataList.add(dataItem);
            } while (cursor.moveToNext());
            cursor.close();
        }

        dataAdapter.notifyDataSetChanged();
    }

    // Request SMS permission
    private void requestSmsPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            Toast.makeText(this, "SMS permission is required to send notifications.", Toast.LENGTH_SHORT).show();
        }
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    // Handle SMS permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Send SMS notification
    private void sendSMSNotification(String phoneNumber, String message) {
        SmsManager smsManager;

        // Use createSmsManager() for API level 31 and above, and getDefault() for older versions
        smsManager = getSystemService(SmsManager.class);

        // Check if the message length is greater than the maximum allowed for a single SMS (160 characters)
        if (message.length() > 160) {
            ArrayList<String> messageParts = smsManager.divideMessage(message);
            smsManager.sendMultipartTextMessage(phoneNumber, null, messageParts, null, null);
        } else {
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        }
        Toast.makeText(this, "SMS notification sent.", Toast.LENGTH_SHORT).show();
    }
}
