package com.example.corderroartzfirstapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "app.db";
    private static final int DATABASE_VERSION = 2; // Incremented version number

    // Table for user credentials
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_PHONE_NUMBER = "phone_number"; // Added phone number column

    // Table for data items
    public static final String TABLE_DATA = "data";
    public static final String COLUMN_DATA_ID = "data_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_DATE = "date";

    // SQL statement to create the user table
    private static final String CREATE_USERS_TABLE =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT, " +
                    COLUMN_PASSWORD + " TEXT, " +
                    COLUMN_PHONE_NUMBER + " TEXT);";

    // SQL statement to create the data table
    private static final String CREATE_DATA_TABLE =
            "CREATE TABLE " + TABLE_DATA + " (" +
                    COLUMN_DATA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_ITEM_NAME + " TEXT, " +
                    COLUMN_DATE + " TEXT);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_DATA_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + COLUMN_PHONE_NUMBER + " TEXT;");
        }
    }

    // Insert data item
    public long insertDataItem(String itemName, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_DATE, date);

        return db.insert(TABLE_DATA, null, values);
    }

    // Get all data items
    public Cursor getAllDataItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_DATA, null, null, null, null, null, null);
    }

    // Update data item
    public int updateDataItem(int id, String itemName, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_DATE, date);

        String selection = COLUMN_DATA_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        return db.update(TABLE_DATA, values, selection, selectionArgs);
    }

    // Delete data item
    public int deleteDataItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = COLUMN_DATA_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        return db.delete(TABLE_DATA, selection, selectionArgs);
    }

    // Get phone number of a user
    public String getPhoneNumber(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = { COLUMN_PHONE_NUMBER };
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = { username };

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            String phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHONE_NUMBER));
            cursor.close();
            return phoneNumber;
        }
        return null;
    }
}
